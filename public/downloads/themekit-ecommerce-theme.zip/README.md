# Shopfront eCommerce Theme (Astro Framework)

High-converting eCommerce and curated lifestyle store landing page with product grid and trust signals.

This is the standalone **Shopfront eCommerce Theme** theme codebase built with **Astro 5+**, **React 19**, and **Tailwind CSS v4**.

## 🚀 Quick Start

1. **Install dependencies**:
```bash
npm install
```

2. **Start the local development server**:
```bash
npm run dev
```

3. **Open in browser**:
Navigate to [http://localhost:4321](http://localhost:4321). Your **Shopfront eCommerce Theme** homepage is ready out of the box!

## 📦 Production Build
```bash
npm run build
npm run preview
```
