import { useState } from 'react';
import { cn } from '../../lib/utils';

/**
 * Navbar component
 * ─────────────────
 * Sticky top navigation with logo, nav links, CTA button, and mobile hamburger.
 * Adapts to light/dark themes via CSS custom properties.
 *
 * Props:
 * @prop logo      - Site name or logo text
 * @prop links     - Array of { label, href } navigation items
 * @prop ctaLabel  - CTA button label (optional)
 * @prop ctaHref   - CTA button href (optional)
 * @prop dark      - Use dark background navbar (for dark-theme pages)
 *
 * @example
 * <Navbar
 *   logo="NexaCloud"
 *   links={[{ label: 'Features', href: '#features' }, { label: 'Pricing', href: '#pricing' }]}
 *   ctaLabel="Start Free Trial"
 *   ctaHref="#signup"
 *   dark
 * />
 */

interface NavLink {
  label: string;
  href: string;
}

interface NavbarProps {
  logo?: string;
  links?: NavLink[];
  ctaLabel?: string;
  ctaHref?: string;
  dark?: boolean;
  logoHref?: string;
  downloadHref?: string;
  downloadLabel?: string;
}

export function Navbar({
  logo = 'Brand',
  links = [],
  ctaLabel,
  ctaHref = '#',
  dark = false,
  logoHref = '/',
  downloadHref = '/downloads/themekit-astro-theme.zip',
  downloadLabel = 'Download Code',
}: NavbarProps) {
  const [open, setOpen] = useState(false);

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full border-b backdrop-blur-md',
        dark
          ? 'border-[var(--color-border)] bg-[var(--color-bg)]/90'
          : 'border-[var(--color-border)] bg-white/90',
      )}
    >
      <nav className="container flex items-center justify-between h-16">
        {/* Logo */}
        <a
          href={logoHref}
          className="text-xl font-bold text-[var(--color-text)] tracking-tight hover:opacity-80 transition-opacity"
        >
          <span className="text-[var(--color-primary)]">{logo.slice(0, 1)}</span>
          {logo.slice(1)}
        </a>

        {/* Desktop nav */}
        <ul className="hidden md:flex items-center gap-1">
          {links.map(link => (
            <li key={link.href}>
              <a
                href={link.href}
                className="px-3 py-2 rounded-[var(--radius-md)] text-sm font-medium text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-bg-subtle)] transition-colors whitespace-nowrap"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-2.5 flex-shrink-0">
          {ctaLabel && (
            <a
              href={ctaHref}
              className="px-4 py-2 text-xs font-bold rounded-[var(--radius-lg)] bg-[var(--color-primary)] text-[var(--color-text-inverse)] hover:bg-[var(--color-primary-dark)] transition-colors shadow-md whitespace-nowrap"
            >
              {ctaLabel}
            </a>
          )}
          <a
            href={downloadHref}
            download={downloadHref.split('/').pop()}
            className="px-3.5 py-2 text-xs font-semibold rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-bg-subtle)] hover:bg-[var(--color-bg-muted)] text-[var(--color-text)] transition-colors flex items-center gap-1.5 shadow-sm whitespace-nowrap"
            title={`${downloadLabel} (.ZIP)`}
          >
            <svg className="w-3.5 h-3.5 text-[var(--color-primary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            <span>{downloadLabel}</span>
          </a>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden p-2 rounded-[var(--radius-md)] text-[var(--color-text-muted)] hover:bg-[var(--color-bg-muted)] transition-colors"
          onClick={() => setOpen(!open)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          {open ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-[var(--color-border)] bg-[var(--color-bg)] px-4 pb-4">
          <ul className="flex flex-col gap-1 pt-2">
            {links.map(link => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block px-4 py-2.5 rounded-[var(--radius-md)] text-sm font-medium text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-bg-subtle)] transition-colors"
                >
                  {link.label}
                </a>
              </li>
            ))}
            {ctaLabel && (
              <li className="mt-2">
                <a
                  href={ctaHref}
                  className="block text-center px-5 py-2.5 text-sm font-semibold rounded-[var(--radius-lg)] bg-[var(--color-primary)] text-[var(--color-text-inverse)] hover:bg-[var(--color-primary-dark)] transition-colors"
                >
                  {ctaLabel}
                </a>
              </li>
            )}
            <li className="mt-2">
              <a
                href={downloadHref}
                download={downloadHref.split('/').pop()}
                className="block text-center px-5 py-2.5 text-sm font-semibold rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-bg-subtle)] text-[var(--color-text)] hover:bg-[var(--color-bg-muted)] transition-colors flex items-center justify-center gap-2"
              >
                <svg className="w-4 h-4 text-[var(--color-primary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                <span>{downloadLabel}</span>
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
