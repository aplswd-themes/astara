import React, { useState, useEffect } from 'react';
import { MotionHeroBackground } from '../interactive/MotionHeroBackground';

interface PopInfo {
  city: string;
  region: string;
  latency: string;
  status: string;
  traffic: string;
}

const POPS: PopInfo[] = [
  { city: 'Frankfurt', region: 'EU-CENTRAL', latency: '0.78ms', status: 'Optimal', traffic: '1.4M req/s' },
  { city: 'Virginia', region: 'US-EAST', latency: '0.65ms', status: 'Optimal', traffic: '2.8M req/s' },
  { city: 'Tokyo', region: 'AP-NORTHEAST', latency: '1.02ms', status: 'Optimal', traffic: '980k req/s' },
  { city: 'Singapore', region: 'AP-SOUTHEAST', latency: '1.14ms', status: 'Optimal', traffic: '820k req/s' },
  { city: 'São Paulo', region: 'SA-EAST', latency: '1.28ms', status: 'Optimal', traffic: '410k req/s' },
];

export const SaasHero: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'terminal' | 'telemetry' | 'security'>('terminal');
  const [selectedPop, setSelectedPop] = useState(0);
  const [terminalOutput, setTerminalOutput] = useState<string[]>([
    '▲ nexacloud deploy --target=edge --region=global',
    '✓ Bundle compiled in 142ms [V8 Isolate Ready]',
    '✓ Deployed to 312 edge PoPs simultaneously',
    '🚀 Cold start latency: 0.74ms | TLS 1.3 handshake: 0.12ms',
    '● Status: Live in production at https://edge.nexacloud.io',
  ]);
  const [isDeploying, setIsDeploying] = useState(false);

  const runCommand = (cmd: string) => {
    setIsDeploying(true);
    if (cmd === 'deploy') {
      setTerminalOutput([
        '▲ nexacloud deploy --prod --atomic',
        '⏳ Building isolated worker container...',
        '✓ Optimized assets: 24.1 KB minified (gzip: 7.2 KB)',
        '✓ Propagating DNS records to 312 PoPs across 6 continents...',
        '🚀 Complete! Atomic cutover finished in 0.82 seconds. Zero downtime.',
      ]);
    } else if (cmd === 'rollback') {
      setTerminalOutput([
        '▲ nexacloud rollback --commit 9a4f2e',
        '⚡ Pinning immutable edge snapshot #149...',
        '✓ Instant pointer redirection executed across all regions',
        '🚀 Rolled back to stable build in 8ms flat. Audit log recorded.',
      ]);
    } else if (cmd === 'metrics') {
      setTerminalOutput([
        '▲ nexacloud telemetry --live --stream',
        '● Ingress traffic: 1,248,900 req/sec | P99 latency: 1.1ms',
        '● CPU utilization: 4.2% | Memory allocated: 18 MB / 128 MB',
        '● DDoS mitigated: 0 threats detected | TLS Certificate: Valid 89d',
      ]);
    }
    setTimeout(() => setIsDeploying(false), 600);
  };

  return (
    <section className="relative overflow-hidden min-h-[96vh] flex flex-col justify-center bg-zinc-950 text-white pt-20 pb-16 lg:py-24 border-b border-zinc-850">
      {/* MotionSites Dynamic Cyber Matrix Background Engine */}
      <MotionHeroBackground variant="saas" />

      <div className="container mx-auto px-4 relative z-10 max-w-6xl">
        {/* Top Centered Status Pill */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full text-xs font-semibold border border-indigo-500/40 bg-indigo-950/70 text-indigo-300 backdrop-blur-md shadow-lg shadow-indigo-500/10">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-bold text-white">V8 EDGE ENGINE 4.0</span>
            <span className="text-zinc-600">|</span>
            <span className="text-zinc-300">Sub-0.8ms Cold Starts Across 312 Global PoPs</span>
          </div>
        </div>

        {/* Centered High-Impact Headline */}
        <div className="text-center max-w-4xl mx-auto mb-10">
          <h1
            className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.06] mb-6"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            Deploy at the{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400">
              speed of thought
            </span>
            ,<br />
            scale without limits.
          </h1>
          <p className="text-base sm:text-xl text-zinc-400 max-w-2xl mx-auto leading-relaxed">
            NexaCloud provisions isolated serverless runtimes worldwide in under 1 second. Zero cold starts, atomic rollbacks, and distributed observability built in.
          </p>

          {/* Centered Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
            <a
              href="#pricing"
              className="inline-flex items-center gap-2.5 px-8 py-4 font-bold rounded-2xl text-xs uppercase tracking-wider text-white transition-all shadow-xl shadow-indigo-600/30 hover:-translate-y-0.5 hover:shadow-indigo-600/50 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"
            >
              <span>Start Free Deployment</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </a>
            <a
              href="#features"
              className="inline-flex items-center gap-2 px-7 py-4 font-bold rounded-2xl text-xs uppercase tracking-wider border border-zinc-800 bg-zinc-900/60 text-zinc-300 transition-all hover:-translate-y-0.5 hover:border-zinc-600 hover:text-white backdrop-blur-md"
            >
              <span>Explore Features</span>
            </a>
          </div>
        </div>

        {/* Panoramic Glassmorphic Command Center Console (Panoramic Architecture) */}
        <div className="w-full rounded-2xl border border-zinc-800 bg-zinc-900/80 backdrop-blur-xl shadow-2xl shadow-black/80 overflow-hidden mb-12">
          {/* Console Top Bar */}
          <div className="flex flex-wrap items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-zinc-950/60">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
              <span className="ml-3 font-mono text-xs text-zinc-400 font-semibold hidden sm:inline-block">
                nexacloud-cluster-us-east // production
              </span>
            </div>

            {/* Console Navigation Tabs */}
            <div className="flex items-center gap-1.5 bg-zinc-900 p-1 rounded-xl border border-zinc-800">
              <button
                onClick={() => setActiveTab('terminal')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'terminal'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                CLI Terminal
              </button>
              <button
                onClick={() => setActiveTab('telemetry')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'telemetry'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Global PoPs (312)
              </button>
              <button
                onClick={() => setActiveTab('security')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'security'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Zero-Trust
              </button>
            </div>
          </div>

          {/* Console Content Window */}
          <div className="p-6">
            {activeTab === 'terminal' && (
              <div>
                {/* Runnable Command Trigger Buttons */}
                <div className="flex flex-wrap items-center gap-2 mb-4">
                  <span className="text-xs uppercase font-extrabold tracking-wider text-zinc-500 mr-2">Quick Run:</span>
                  <button
                    onClick={() => runCommand('deploy')}
                    disabled={isDeploying}
                    className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-indigo-300 font-mono text-xs font-semibold border border-zinc-700 transition-all hover:border-indigo-500"
                  >
                    deploy --prod
                  </button>
                  <button
                    onClick={() => runCommand('rollback')}
                    disabled={isDeploying}
                    className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-amber-300 font-mono text-xs font-semibold border border-zinc-700 transition-all hover:border-amber-500"
                  >
                    rollback --atomic
                  </button>
                  <button
                    onClick={() => runCommand('metrics')}
                    disabled={isDeploying}
                    className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-emerald-300 font-mono text-xs font-semibold border border-zinc-700 transition-all hover:border-emerald-500"
                  >
                    telemetry --live
                  </button>
                </div>

                {/* Simulated CLI Terminal Screen */}
                <div className="rounded-xl bg-black/90 p-5 font-mono text-xs sm:text-sm text-zinc-300 border border-zinc-850 space-y-2 shadow-inner">
                  {terminalOutput.map((line, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="text-indigo-400 select-none">&gt;</span>
                      <span className={idx === 0 ? 'text-white font-bold' : idx === terminalOutput.length - 1 ? 'text-emerald-400 font-bold' : 'text-zinc-400'}>
                        {line}
                      </span>
                    </div>
                  ))}
                  {isDeploying && (
                    <div className="text-indigo-400 animate-pulse flex items-center gap-2">
                      <span className="inline-block w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
                      <span>Executing across distributed clusters...</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'telemetry' && (
              <div>
                <p className="text-xs text-zinc-400 mb-4 font-medium">
                  Select an edge Point of Presence to view real-time latency and ingress capacity:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                  {POPS.map((pop, idx) => (
                    <button
                      key={pop.city}
                      onClick={() => setSelectedPop(idx)}
                      className={`p-4 rounded-xl text-left transition-all border ${
                        selectedPop === idx
                          ? 'border-indigo-500 bg-indigo-950/40 shadow-lg shadow-indigo-500/20'
                          : 'border-zinc-800 bg-zinc-950/40 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-white">{pop.city}</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      </div>
                      <div className="text-2xl font-mono font-black text-indigo-400">{pop.latency}</div>
                      <div className="text-[10px] text-zinc-500 uppercase tracking-wider mt-1">{pop.traffic}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="text-emerald-400 text-lg font-bold mb-1">SOC 2 Type II</div>
                  <p className="text-xs text-zinc-400">Certified infrastructure with continuous automated compliance audits.</p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="text-indigo-400 text-lg font-bold mb-1">mTLS 1.3 Strict</div>
                  <p className="text-xs text-zinc-400">Every packet encrypted in transit between edge worker isolates.</p>
                </div>
                <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800">
                  <div className="text-purple-400 text-lg font-bold mb-1">DDoS Shield</div>
                  <p className="text-xs text-zinc-400">120 Tbps mitigation capacity absorbing Layer 3, 4, and 7 vector attacks.</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Specs Metrics Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-zinc-850">
          <div className="text-center sm:text-left">
            <div className="text-2xl font-mono font-black text-white">&lt; 0.8ms</div>
            <div className="text-xs text-zinc-500 font-semibold uppercase tracking-wider">Cold-Start Boot</div>
          </div>
          <div className="text-center sm:text-left">
            <div className="text-2xl font-mono font-black text-emerald-400">312</div>
            <div className="text-xs text-zinc-500 font-semibold uppercase tracking-wider">Global Edge PoPs</div>
          </div>
          <div className="text-center sm:text-left">
            <div className="text-2xl font-mono font-black text-indigo-400">99.999%</div>
            <div className="text-xs text-zinc-500 font-semibold uppercase tracking-wider">SLA Guarantee</div>
          </div>
          <div className="text-center sm:text-left">
            <div className="text-2xl font-mono font-black text-purple-400">1.2B</div>
            <div className="text-xs text-zinc-500 font-semibold uppercase tracking-wider">Requests Daily</div>
          </div>
        </div>
      </div>
    </section>
  );
};
