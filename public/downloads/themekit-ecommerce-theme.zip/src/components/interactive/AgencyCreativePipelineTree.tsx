import React, { useState } from 'react';
import { MEDIA } from '../../lib/media';

interface PipelineBranch {
  id: string;
  stage: string;
  title: string;
  subtitle: string;
  deliverables: string[];
  image: string;
  clientStory: string;
  metric: string;
  award: string;
}

const BRANCHES: PipelineBranch[] = [
  {
    id: 'discovery',
    stage: 'Phase 01',
    title: 'Cultural Semiotics & Positioning Moat',
    subtitle: 'Narrative Strategy & Brand Architecture',
    deliverables: [
      'Category Deconstruction & Whitespace Mapping',
      'Archetype Positioning & Verbal Manifesto',
      'Executive Leadership Immersion Workshops',
      'Brand Architecture & Portfolio Naming System',
    ],
    image: MEDIA.agency.studioSpace,
    clientStory: 'How we shifted Altitude Aerospace from an industrial logistics company into an elite commercial flight brand.',
    metric: '+180% Inbound Inquiries',
    award: 'Strat & Narrative Award 2024',
  },
  {
    id: 'identity',
    stage: 'Phase 02',
    title: 'Generative Typography & Design Tokens',
    subtitle: 'Bespoke Visual Foundations & Foundry',
    deliverables: [
      'Proprietary Dual-Axis Variable Typeface',
      'Kinetic Brand Tokens & Color Harmonies',
      'Sub-Pixel Micro-Interaction Library',
      'Interactive Living Guidelines Edge Portal',
    ],
    image: MEDIA.agency.lumina,
    clientStory: 'Crafting Lune Botanicals tactile cold-pressed packaging and custom display serif for Parisian flagship stores.',
    metric: 'Dieline Best in Class',
    award: 'Red Dot: Best of the Best',
  },
  {
    id: 'digital',
    stage: 'Phase 03',
    title: 'Spatial 3D & WebGL Flagship Architecture',
    subtitle: 'Headless Edge Experience Engineering',
    deliverables: [
      'Interactive 3D WebGL Canvas Renderers',
      'Sub-0.5s Headless Astro & Next.js Architecture',
      'Soundscape Spatial Audio Design',
      'Accessible WCAG AAA Compliance Suite',
    ],
    image: MEDIA.agency.meridian,
    clientStory: 'Architecting Meridian Capital institutional wealth dashboard with real-time portfolio telemetry.',
    metric: '$45M Series B Scaled',
    award: 'Awwwards Site of the Month',
  },
  {
    id: 'campaign',
    stage: 'Phase 04',
    title: 'Cinematic Launch Film & Global Rollout',
    subtitle: 'Omnichannel Cultural Resonance',
    deliverables: [
      '4K Cinematic Brand Manifesto Films',
      'Global Out-Of-Home Multi-City Takeovers',
      'Interactive Press & Investor Launch Kits',
      'Continuous Brand Stewardship & Evolution',
    ],
    image: MEDIA.agency.solis,
    clientStory: 'Directing Crest Horology multi-sensory global premiere across New York, Tokyo, and London.',
    metric: '2.4M Organic Views',
    award: 'Cannes Lions Design Shortlist',
  },
];

export const AgencyCreativePipelineTree: React.FC = () => {
  const [selectedBranch, setSelectedBranch] = useState<PipelineBranch>(BRANCHES[1]);

  return (
    <section className="my-24 py-20 px-4 rounded-3xl border border-orange-500/20 bg-stone-950 text-white relative overflow-hidden shadow-2xl">
      {/* Ambient background glows */}
      <div className="absolute -top-32 left-10 w-[500px] h-[500px] bg-orange-600/15 rounded-full blur-3xl pointer-events-none animate-pulse-glow"></div>
      <div className="absolute -bottom-32 right-10 w-[450px] h-[450px] bg-amber-600/15 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-serif font-semibold mb-4 border border-orange-500/30 bg-orange-950/50 text-orange-400">
            <span>✦ THE ATELIER CREATIVE EVOLUTION TREE</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white font-sans leading-tight">
            How we translate vision into <span className="italic font-serif text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-300 to-yellow-400">market authority</span>.
          </h2>
          <p className="text-base text-stone-400 mt-4 leading-relaxed font-sans">
            Every studio engagement follows our rigorous four-phase creative pipeline. Click through each branch of our methodology to inspect deliverables, awards, and case outcomes.
          </p>
        </div>

        {/* Tree Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: 4 Stages / Branches */}
          <div className="lg:col-span-6 space-y-4">
            {BRANCHES.map((b, idx) => {
              const isSelected = selectedBranch.id === b.id;
              return (
                <div
                  key={b.id}
                  onClick={() => setSelectedBranch(b)}
                  className={`p-6 rounded-2xl border transition-all duration-300 cursor-pointer group relative ${
                    isSelected
                      ? 'bg-stone-900 border-orange-500/80 shadow-xl shadow-orange-950/40 ring-1 ring-orange-500/40 -translate-y-0.5'
                      : 'bg-stone-900/40 border-stone-800/80 hover:bg-stone-900/80 hover:border-stone-700'
                  }`}
                >
                  {/* Visual Branch Line Indicator */}
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2.5 mb-2">
                        <span className="text-xs font-mono font-bold text-orange-400 uppercase tracking-widest">
                          {b.stage}
                        </span>
                        <span className="text-stone-600">·</span>
                        <span className="text-xs font-mono text-stone-400">
                          {b.subtitle}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold text-white group-hover:text-orange-300 transition-colors font-sans">
                        {b.title}
                      </h3>
                    </div>

                    <span
                      className={`w-8 h-8 rounded-full border flex items-center justify-center text-xs font-bold transition-all shrink-0 ${
                        isSelected
                          ? 'bg-orange-600 border-white text-white shadow-md'
                          : 'bg-stone-950 border-stone-800 text-stone-500'
                      }`}
                    >
                      0{idx + 1}
                    </span>
                  </div>

                  {/* Micro metric snippet */}
                  <div className="mt-4 pt-3 border-t border-stone-850 flex items-center justify-between text-xs text-stone-400">
                    <span className="text-[11px] font-mono font-semibold text-amber-400">
                      🏆 {b.award}
                    </span>
                    <span className="font-mono text-orange-400 font-bold">
                      {b.metric}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right: Selected Stage Gallery & Deliverable Card */}
          <div className="lg:col-span-6 sticky top-24">
            <div className="rounded-3xl border border-orange-500/30 bg-stone-900/90 backdrop-blur-xl overflow-hidden shadow-2xl">
              {/* Deliverable Image Preview */}
              <div className="h-64 sm:h-72 w-full relative overflow-hidden bg-black">
                <img
                  src={selectedBranch.image}
                  alt={selectedBranch.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 filter brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent"></div>

                <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-widest font-mono font-bold px-3 py-1 rounded-full bg-black/70 text-orange-400 border border-orange-500/30 backdrop-blur-md">
                    {selectedBranch.stage} DELIVERABLE SHOWCASE
                  </span>
                  <span className="text-xs font-mono font-bold px-3 py-1 rounded-full bg-orange-600 text-white shadow-md">
                    {selectedBranch.metric}
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-black/70 backdrop-blur-md border border-white/10">
                  <p className="text-[10px] uppercase font-bold text-amber-400 font-mono">Case Study Highlight</p>
                  <p className="text-sm font-medium text-stone-200 mt-0.5">{selectedBranch.clientStory}</p>
                </div>
              </div>

              {/* Deliverables List */}
              <div className="p-6 sm:p-7 space-y-4">
                <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                  <span className="text-xs font-mono uppercase font-bold tracking-widest text-stone-400">
                    Phase Deliverables & Assets
                  </span>
                  <span className="text-xs text-orange-400 font-bold">100% Bespoke</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {selectedBranch.deliverables.map((item, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-2.5 p-3 rounded-xl bg-stone-950/80 border border-stone-800/80 text-xs text-stone-300 font-sans"
                    >
                      <span className="text-orange-400 font-bold shrink-0">✦</span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-stone-800 flex items-center justify-between">
                  <span className="text-xs text-stone-400">Ready to initiate your commission?</span>
                  <a
                    href="/contact"
                    className="px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider bg-gradient-to-r from-orange-600 to-amber-600 text-white hover:shadow-lg hover:shadow-orange-600/30 transition-all hover:scale-105"
                  >
                    Schedule Briefing →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
