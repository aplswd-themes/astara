import React, { useState, useEffect } from 'react';

interface TreeNode {
  id: string;
  name: string;
  category: string;
  status: 'active' | 'synced' | 'standby';
  latency: string;
  detail: string;
  specs: string[];
  icon: string;
}

const NODES: TreeNode[] = [
  {
    id: 'git-origin',
    name: 'Git Origin & Webhooks',
    category: 'Source Control',
    status: 'synced',
    latency: '12ms',
    detail: 'Triggers on git push to main with automatic branch previews, cryptographic commit verification, and monorepo path filters.',
    specs: ['GitHub / GitLab / Bitbucket', 'Instant SHA verification', 'Parallel matrix triggers'],
    icon: '🐙',
  },
  {
    id: 'wasm-compiler',
    name: 'Isolates & WASM Engine',
    category: 'Edge Compilation',
    status: 'active',
    latency: '0.4ms',
    detail: 'Ultra-fast V8 Isolates packaging with Rust and TypeScript tree-shaking. Zero node_modules overhead deployed directly to edge memory.',
    specs: ['Sub-millisecond cold boot', 'Rust & WASM bytecode', 'Memory bounded (128MB)'],
    icon: '⚡',
  },
  {
    id: 'zero-trust',
    name: 'Zero-Trust Shield & RBAC',
    category: 'Security Mesh',
    status: 'synced',
    latency: '1.2ms',
    detail: 'Hardware-level mTLS encryption, edge DDoS scrubbers, SOC 2 Type II compliance policies, and automated secret injection.',
    specs: ['TLS 1.3 Termination', 'Automated Let\'s Encrypt SSL', 'Dynamic token rotation'],
    icon: '🛡️',
  },
  {
    id: 'global-pops',
    name: 'Anycast Edge PoP Network',
    category: 'Global Mesh',
    status: 'active',
    latency: '8ms avg',
    detail: '312 distributed points-of-presence globally connected over private fiber backbones with intelligent BGP geolocation routing.',
    specs: ['Tokyo (NRT) · 4ms', 'Frankfurt (FRA) · 7ms', 'San Jose (SJC) · 2ms', 'London (LHR) · 5ms'],
    icon: '🌐',
  },
  {
    id: 'atomic-rollback',
    name: 'Atomic Rollback Guard',
    category: 'Delivery & Guardrails',
    status: 'standby',
    latency: '&lt; 1s',
    detail: 'Zero-downtime pointer swapping with automatic 5xx error canary detection and automated instantaneous rollback in 800ms.',
    specs: ['Canary traffic split (1-99%)', 'Automatic SLO circuit breaker', 'Instant DNS pointer shift'],
    icon: '🔄',
  },
];

export const SaasArchitectureTree: React.FC = () => {
  const [activeNode, setActiveNode] = useState<TreeNode>(NODES[1]);
  const [isDeploying, setIsDeploying] = useState(false);
  const [activeStep, setActiveStep] = useState(1);

  const triggerDeploySimulation = () => {
    if (isDeploying) return;
    setIsDeploying(true);
    setActiveStep(0);
    let step = 0;
    const interval = setInterval(() => {
      step++;
      if (step < NODES.length) {
        setActiveStep(step);
        setActiveNode(NODES[step]);
      } else {
        clearInterval(interval);
        setIsDeploying(false);
      }
    }, 900);
  };

  return (
    <section className="my-20 py-16 px-4 rounded-3xl border border-indigo-500/30 bg-zinc-950 text-white relative overflow-hidden shadow-2xl">
      {/* Background ambient lighting */}
      <div className="absolute -top-40 left-1/3 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none animate-pulse-glow"></div>
      <div className="absolute -bottom-40 right-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold mb-3 border border-indigo-500/40 bg-indigo-950/60 text-indigo-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>LIVE EDGE ARCHITECTURE TREE</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white font-sans">
              Distributed Edge Pipeline <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400">& Telemetry Tree</span>
            </h2>
            <p className="text-sm sm:text-base text-zinc-400 mt-2 max-w-xl">
              Inspect how every push propagates through isolated V8 runtimes across 312 global PoPs in sub-second latency.
            </p>
          </div>

          <button
            onClick={triggerDeploySimulation}
            disabled={isDeploying}
            className={`px-5 py-3 rounded-2xl text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2.5 transition-all shadow-lg ${
              isDeploying
                ? 'bg-zinc-800 text-zinc-400 cursor-not-allowed border border-zinc-700'
                : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-indigo-500/30 hover:scale-105 active:scale-95'
            }`}
          >
            <span className={isDeploying ? 'animate-spin' : ''}>⚙️</span>
            <span>{isDeploying ? `Deploying to Edge Node ${activeStep + 1}/5...` : 'Simulate Edge Deploy'}</span>
          </button>
        </div>

        {/* Tree Pipeline Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Tree Flow Chart with Branch Connectors */}
          <div className="lg:col-span-7 space-y-4 relative">
            {/* Visual Connecting Line Behind Nodes */}
            <div className="absolute left-8 top-10 bottom-10 w-0.5 bg-gradient-to-b from-indigo-500 via-purple-500 to-emerald-500 hidden sm:block opacity-40"></div>

            {NODES.map((node, index) => {
              const isSelected = activeNode.id === node.id;
              const isCurrentSimStep = isDeploying && activeStep === index;

              return (
                <div
                  key={node.id}
                  onClick={() => setActiveNode(node)}
                  className={`group relative p-5 rounded-2xl border transition-all duration-300 cursor-pointer sm:ml-16 ${
                    isSelected
                      ? 'bg-zinc-900/95 border-indigo-500 shadow-xl shadow-indigo-950/60 ring-1 ring-indigo-500/50 -translate-y-0.5'
                      : 'bg-zinc-900/40 border-zinc-800/80 hover:bg-zinc-900/70 hover:border-zinc-700'
                  }`}
                >
                  {/* Circular Node Anchor on Connector Line */}
                  <div
                    className={`absolute -left-16 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full border-2 hidden sm:flex items-center justify-center text-xs font-mono font-bold transition-all shadow-md ${
                      isSelected || isCurrentSimStep
                        ? 'bg-indigo-600 border-white text-white ring-4 ring-indigo-500/30 scale-110'
                        : 'bg-zinc-950 border-zinc-700 text-zinc-400'
                    }`}
                  >
                    {index + 1}
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5">
                      <span className="text-2xl p-2 rounded-xl bg-zinc-950 border border-zinc-800 shadow-inner group-hover:scale-110 transition-transform">
                        {node.icon}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono uppercase font-bold tracking-wider text-indigo-400">
                            {node.category}
                          </span>
                          {isCurrentSimStep && (
                            <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                              Processing Packet
                            </span>
                          )}
                        </div>
                        <h4 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors">
                          {node.name}
                        </h4>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-lg border border-emerald-500/30 block">
                        {node.latency}
                      </span>
                      <span className="text-[10px] font-mono text-zinc-500 mt-1 block uppercase">
                        {node.status}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right: Live Node Telemetry HUD Inspector */}
          <div className="lg:col-span-5 sticky top-24">
            <div className="rounded-3xl border border-indigo-500/40 bg-zinc-900/90 backdrop-blur-xl p-6 sm:p-7 shadow-2xl shadow-indigo-950/80">
              <div className="flex items-center justify-between pb-5 border-b border-zinc-800">
                <div className="flex items-center gap-2.5">
                  <span className="text-3xl p-2.5 rounded-2xl bg-zinc-950 border border-indigo-500/30">
                    {activeNode.icon}
                  </span>
                  <div>
                    <span className="text-[10px] font-mono uppercase font-extrabold tracking-wider text-indigo-400">
                      TELEMETRY INSPECTOR
                    </span>
                    <h3 className="text-lg font-black text-white font-sans">
                      {activeNode.name}
                    </h3>
                  </div>
                </div>
                <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></span>
              </div>

              {/* Node Detailed Description */}
              <div className="py-5 border-b border-zinc-800">
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-sans">
                  {activeNode.detail}
                </p>
              </div>

              {/* Node Technical Specs */}
              <div className="py-5 space-y-3">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-zinc-400">
                  Architectural Specifications
                </span>
                <div className="space-y-2">
                  {activeNode.specs.map((spec, i) => (
                    <div key={i} className="flex items-center gap-2.5 text-xs text-zinc-200 font-mono bg-zinc-950/70 px-3 py-2 rounded-xl border border-zinc-800/80">
                      <span className="text-emerald-400">✔</span>
                      <span>{spec}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live Terminal Output for Node */}
              <div className="p-3.5 rounded-xl bg-black/90 font-mono text-[11px] text-zinc-400 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-[10px] text-zinc-500 border-b border-zinc-900 pb-1 mb-1">
                  <span>RUNTIME LOGS</span>
                  <span className="text-emerald-400 font-bold">HEALTHY</span>
                </div>
                <p><span className="text-indigo-400">trace_id:</span> {activeNode.id}-89f2a0</p>
                <p><span className="text-indigo-400">latency_p99:</span> {activeNode.latency}</p>
                <p className="text-emerald-400">isolates_v8: zero memory leak detected</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
