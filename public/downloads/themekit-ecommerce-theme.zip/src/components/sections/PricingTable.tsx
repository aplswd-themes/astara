import { useState } from 'react';
import { cn } from '../../lib/utils';

/**
 * PricingTable component
 * ───────────────────────
 * Billing-period toggle + 3-column pricing cards.
 * Highlighted "popular" tier draws attention to recommended plan.
 *
 * Props:
 * @prop title      - Section heading
 * @prop subtitle   - Section eyebrow label
 * @prop plans      - Array of pricing plan objects
 * @prop showToggle - Show monthly/annual toggle (default: true)
 *
 * Plan object:
 * { name, description, monthlyPrice, annualPrice, features, cta, ctaHref, popular }
 *
 * @example
 * <PricingTable
 *   title="Simple, transparent pricing"
 *   plans={[
 *     { name: 'Starter', monthlyPrice: 0, annualPrice: 0, features: ['5 projects', '1 GB storage'], cta: 'Get started free' },
 *     { name: 'Pro', monthlyPrice: 29, annualPrice: 19, features: ['Unlimited projects', '100 GB storage'], cta: 'Start Pro trial', popular: true },
 *     { name: 'Enterprise', monthlyPrice: 99, annualPrice: 79, features: ['Custom limits', 'SSO', 'SLA'], cta: 'Contact sales' },
 *   ]}
 * />
 */

interface Plan {
  name: string;
  description?: string;
  monthlyPrice: number | 'Custom';
  annualPrice: number | 'Custom';
  features: string[];
  cta: string;
  ctaHref?: string;
  popular?: boolean;
}

interface PricingTableProps {
  title?: string;
  subtitle?: string;
  plans: Plan[];
  showToggle?: boolean;
}

export function PricingTable({
  title = 'Choose your plan',
  subtitle = 'Pricing',
  plans,
  showToggle = true,
}: PricingTableProps) {
  const [annual, setAnnual] = useState(false);

  return (
    <section className="section bg-[var(--color-bg)]">
      <div className="container">
        <div className="text-center mb-16">
          <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-[var(--color-primary)]">
            {subtitle}
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[var(--color-text)] mb-6">{title}</h2>

          {showToggle && (
            <div className="inline-flex items-center gap-3 p-1 rounded-full border border-[var(--color-border)] bg-[var(--color-bg-subtle)]">
              <button
                onClick={() => setAnnual(false)}
                className={cn(
                  'px-5 py-2 rounded-full text-sm font-medium transition-all',
                  !annual
                    ? 'bg-[var(--color-primary)] text-[var(--color-text-inverse)] shadow'
                    : 'text-[var(--color-text-muted)] hover:text-[var(--color-text)]',
                )}
              >
                Monthly
              </button>
              <button
                onClick={() => setAnnual(true)}
                className={cn(
                  'px-5 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2',
                  annual
                    ? 'bg-[var(--color-primary)] text-[var(--color-text-inverse)] shadow'
                    : 'text-[var(--color-text-muted)] hover:text-[var(--color-text)]',
                )}
              >
                Annual
                <span className="text-xs bg-emerald-500 text-white px-1.5 py-0.5 rounded-full font-semibold">
                  Save 30%
                </span>
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {plans.map(plan => {
            const price = annual ? plan.annualPrice : plan.monthlyPrice;

            return (
              <div
                key={plan.name}
                className={cn(
                  'relative flex flex-col gap-6 p-8 rounded-[var(--radius-2xl)] border transition-all',
                  plan.popular
                    ? 'border-[var(--color-primary)] bg-[var(--color-primary)] shadow-[var(--shadow-xl)] scale-105 z-10'
                    : 'border-[var(--color-border)] bg-[var(--color-bg-subtle)] hover:border-[var(--color-primary)] hover:-translate-y-1',
                )}
              >
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-[var(--color-accent)] text-white text-xs font-bold rounded-full shadow">
                    Most Popular
                  </span>
                )}

                <div>
                  <h3
                    className={cn(
                      'text-xl font-bold mb-1',
                      plan.popular ? 'text-white' : 'text-[var(--color-text)]',
                    )}
                  >
                    {plan.name}
                  </h3>
                  {plan.description && (
                    <p
                      className={cn(
                        'text-sm',
                        plan.popular ? 'text-white/70' : 'text-[var(--color-text-muted)]',
                      )}
                    >
                      {plan.description}
                    </p>
                  )}
                </div>

                <div className="flex items-end gap-1">
                  {typeof price === 'number' ? (
                    <>
                      <span
                        className={cn(
                          'text-4xl font-extrabold',
                          plan.popular ? 'text-white' : 'text-[var(--color-text)]',
                        )}
                      >
                        ${price}
                      </span>
                      <span
                        className={cn(
                          'text-sm mb-1.5',
                          plan.popular ? 'text-white/70' : 'text-[var(--color-text-muted)]',
                        )}
                      >
                        / {annual ? 'mo, billed yearly' : 'month'}
                      </span>
                    </>
                  ) : (
                    <span
                      className={cn(
                        'text-4xl font-extrabold',
                        plan.popular ? 'text-white' : 'text-[var(--color-text)]',
                      )}
                    >
                      Custom
                    </span>
                  )}
                </div>

                <ul className="flex flex-col gap-3 flex-1">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-start gap-2.5">
                      <svg
                        className={cn(
                          'w-4 h-4 mt-0.5 shrink-0',
                          plan.popular ? 'text-white' : 'text-[var(--color-primary)]',
                        )}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span
                        className={cn(
                          'text-sm',
                          plan.popular ? 'text-white/90' : 'text-[var(--color-text-muted)]',
                        )}
                      >
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>

                <a
                  href={plan.ctaHref ?? '#'}
                  className={cn(
                    'block text-center px-6 py-3 rounded-[var(--radius-lg)] font-semibold text-sm transition-all',
                    plan.popular
                      ? 'bg-white text-[var(--color-primary)] hover:bg-white/90 shadow'
                      : 'bg-[var(--color-primary)] text-[var(--color-text-inverse)] hover:bg-[var(--color-primary-dark)] shadow-md',
                  )}
                >
                  {plan.cta}
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
