import { useState } from 'react';

/**
 * FAQ component
 * ──────────────
 * Accessible accordion FAQ section.
 * Only one item open at a time (single-expand mode).
 *
 * Props:
 * @prop title  - Section heading
 * @prop items  - Array of { question, answer }
 * @prop dark   - Dark background variant
 *
 * @example
 * <FAQ
 *   title="Frequently asked questions"
 *   items={[
 *     { question: 'Is there a free trial?', answer: 'Yes — 14 days, no credit card required.' },
 *     { question: 'Can I cancel anytime?', answer: 'Absolutely. No lock-in contracts.' },
 *   ]}
 * />
 */

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQProps {
  title?: string;
  subtitle?: string;
  items: FAQItem[];
  dark?: boolean;
}

export function FAQ({ title = 'Frequently asked questions', subtitle = 'FAQ', items, dark = false }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (i: number) => setOpenIndex(prev => (prev === i ? null : i));

  return (
    <section className={`section ${dark ? 'bg-[var(--color-bg-subtle)]' : 'bg-[var(--color-bg)]'}`}>
      <div className="container">
        <div className="text-center mb-16">
          <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-[var(--color-primary)]">
            {subtitle}
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[var(--color-text)]">{title}</h2>
        </div>

        <div className="max-w-3xl mx-auto flex flex-col gap-3">
          {items.map((item, i) => (
            <div
              key={i}
              className="rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-[var(--color-bg-subtle)] overflow-hidden"
            >
              <button
                className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left text-[var(--color-text)] font-semibold hover:bg-[var(--color-bg-muted)] transition-colors"
                onClick={() => toggle(i)}
                aria-expanded={openIndex === i}
              >
                <span>{item.question}</span>
                <svg
                  className={`w-5 h-5 shrink-0 text-[var(--color-primary)] transition-transform duration-200 ${openIndex === i ? 'rotate-45' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </button>

              {openIndex === i && (
                <div className="px-6 pb-5">
                  <p className="text-sm text-[var(--color-text-muted)] leading-relaxed">{item.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
